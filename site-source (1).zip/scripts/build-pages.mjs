import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const root=path.resolve(import.meta.dirname,'..');
const require=createRequire(process.env.HOOK_RENDER_RUNTIME || path.join(root,'package.json'));
const React=require('react');
const {renderToStaticMarkup}=require('react-dom/server');
const ts=require('typescript');
const origin='https://syntheos.site';
const source=path.join(root,'source');
const out=path.join(root,'_site');
const cache=new Map();
function load(file){
  if(cache.has(file))return cache.get(file);
  if(file.endsWith('.json'))return JSON.parse(fs.readFileSync(file,'utf8'));
  const js=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText;
  const mod={exports:{}};
  function local(name){
    if(name==='next/link')return {__esModule:true,default:({href,children,...props})=>React.createElement('a',{...props,href},children)};
    if(name==='next/navigation')return {notFound:()=>{throw new Error('Unknown guide');}};
    if(name==='@/lib/product')return {...load(path.join(source,'lib/product.ts')),ORIGIN:origin};
    if(name.startsWith('@/'))return resolve(path.join(source,name.slice(2)));
    if(name.startsWith('.'))return resolve(path.resolve(path.dirname(file),name));
    return require(name);
  }
  new Function('require','module','exports',js)(local,mod,mod.exports);
  cache.set(file,mod.exports);return mod.exports;
}
function resolve(stem){for(const suffix of ['', '.ts','.tsx','.json'])if(fs.existsSync(stem+suffix))return load(stem+suffix);throw new Error('Missing source: '+stem);}
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const {guides}=load(path.join(source,'lib/content.ts'));
fs.rmSync(out,{recursive:true,force:true});fs.mkdirSync(out,{recursive:true});
fs.cpSync(path.join(root,'public'),out,{recursive:true});
fs.cpSync(path.join(root,'legacy'),path.join(out,'legacy'),{recursive:true});
fs.writeFileSync(path.join(out,'style.css'),fs.readFileSync(path.join(source,'app/globals.css'),'utf8').replace("@import 'tailwindcss';",''));
fs.copyFileSync(path.join(root,'scripts/events.js'),path.join(out,'events.js'));
fs.copyFileSync(path.join(root,'scripts/fit-check.js'),path.join(out,'fit-check.js'));
const routes=[['/','app/page.tsx','en'],['/de/','app/de/page.tsx','de'],['/checklist/','app/checklist/page.tsx','en'],['/privacy/','app/privacy/page.tsx','en'],...guides.flatMap(g=>[['/guides/'+g.slug+'/','app/guides/[slug]/page.tsx','en',g.slug],['/de/guides/'+g.slug+'/','app/de/guides/[slug]/page.tsx','de',g.slug]])];
for(const [url,file,lang,slug] of routes){
  const mod=load(path.join(source,file));const props={params:Promise.resolve({slug})};
  const metadata=mod.generateMetadata?await mod.generateMetadata(props):mod.metadata||{};
  const title=metadata.title||'Hidden Tile Hook — Concealed Towel Hook STL Kit';
  const description=metadata.description||'Digital STL/3MF kit for a concealed towel hook in a suitable existing tiled solid wall. Separate long K-Push hardware required.';
  const body=renderToStaticMarkup(await mod.default(props));
  const alternates=Object.entries(metadata.alternates?.languages||((url==='/'||url==='/de/')?{en:'/',de:'/de/','x-default':'/'}:{})).map(([l,u])=>`<link rel="alternate" hreflang="${esc(l)}" href="${origin}${esc(u==='/'?u:u.replace(/\/$/,'')+'/')}">`).join('');
  const head=`<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><meta name="description" content="${esc(description)}"><link rel="canonical" href="${origin}${url}">${alternates}<meta name="p:domain_verify" content="1a5efedfe3b8783b476a639acaa0ba43"><meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(description)}"><meta property="og:url" content="${origin}${url}"><meta property="og:image" content="${origin}/hook-concept-v3.png"><meta property="og:type" content="website"><link rel="icon" href="/favicon.svg"><link rel="stylesheet" href="/style.css"><script defer src="/events.js"></script><script defer src="/fit-check.js"></script>`;
  const dir=path.join(out,url);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'index.html'),`<!doctype html><html lang="${lang}"><head>${head}</head><body>${body}</body></html>`);
}
const now=process.env.HOOK_FEED_NOW?Date.parse(process.env.HOOK_FEED_NOW):Date.now();
if(!Number.isFinite(now))throw new Error('Invalid HOOK_FEED_NOW');
fs.writeFileSync(path.join(out,'feed.xml'),load(path.join(source,'lib/feed.ts')).feedAt(now));
fs.writeFileSync(path.join(out,'sitemap.xml'),`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${routes.map(([u])=>`<url><loc>${origin}${u}</loc></url>`).join('')}</urlset>`);
fs.writeFileSync(path.join(out,'robots.txt'),`User-agent: *\nAllow: /\nDisallow: /legacy/\nSitemap: ${origin}/sitemap.xml\n`);
fs.writeFileSync(path.join(out,'CNAME'),'syntheos.site\n');fs.writeFileSync(path.join(out,'.nojekyll'),'');
fs.writeFileSync(path.join(out,'404.html'),'<!doctype html><html lang="en"><meta charset="utf-8"><title>Page not found | Hidden Tile Hook</title><link rel="stylesheet" href="/style.css"><main class="wrap article"><h1>Page not found</h1><a class="button" href="/">Return to Hidden Tile Hook</a></main></html>');
console.log(`Built ${routes.length} static pages and dated RSS for ${origin}`);
