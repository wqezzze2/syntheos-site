(() => {
  const incoming = new URLSearchParams(location.search).get('utm_content');
  const source = incoming && /^pin-(0[1-9]|1\d|2[0-4])$/.test(incoming) ? incoming : 'direct';
  const endpoint = 'https://hidden-tile-hook.lkje24321.chatgpt.site/api/event';
  const send = event => fetch(endpoint, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({event,source}),keepalive:true,credentials:'omit'}).catch(() => {});
  send('page_view');
  document.addEventListener('click', e => {
    const a = e.target instanceof Element ? e.target.closest('a[data-event]') : null;
    if (a) send(a.dataset.event);
  });
})();
