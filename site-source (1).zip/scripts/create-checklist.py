from pathlib import Path
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
root=Path(__file__).resolve().parents[1]
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleHook',fontName='Helvetica-Bold',fontSize=24,leading=28,textColor=colors.HexColor('#153361'),spaceAfter=14))
styles.add(ParagraphStyle(name='HookText',fontName='Helvetica',fontSize=10.5,leading=15,spaceAfter=9))
styles.add(ParagraphStyle(name='HookSmall',fontName='Helvetica',fontSize=8.5,leading=12,textColor=colors.HexColor('#475569')))
rows=[
('1. Wall construction','Establish a suitable solid backing. This kit excludes hollow walls and tiled sheet material on framing. Unknown backing is a reason to pause.'),
('2. Space for the assembly','The creator states a 25 mm opening and about 80 mm behind the tile. Confirm the complete assembly dimensions in the actual installation documentation.'),
('3. Concealed services','Check for wiring and pipes before drilling. This checklist cannot establish that a particular location is safe.'),
('4. Exact hardware','Confirm the long K-Push mechanism specified by the creator. Do not assume a short latch or similar hardware is interchangeable.'),
('5. Files and license','Review the current STL/3MF file inventory, license and supplied instructions on Cults3D. No physical hook is shipped.'),
('6. Tools and tile finish','Plan printing, suitable adhesives and cutting tools. Use an off-cut or spare tile to assess the cut and pattern before the final wall.')]
story=[Paragraph('HIDDEN TILE HOOK',styles['HookSmall']),Spacer(1,7),Paragraph('Before you cut:<br/>the pre-build checklist',styles['TitleHook']),Paragraph('A free planning aid for the concealed towel hook digital kit. No registration required.',styles['HookText'])]
for title,body in rows:
 table=Table([[Paragraph('[  ]',styles['HookText']),Paragraph('<b>'+title+'</b><br/>'+body,styles['HookText'])]],colWidths=[30,450])
 table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,-1),0.4,colors.HexColor('#d5deea'))]));story.append(table)
story += [Spacer(1,17),Paragraph('<b>Explore the original files</b>',styles['HookText']),Paragraph('<link href="https://cults3d.com/en/3d-model/home/under-tile-towel-hook-concealed-k-push-hidden-bathroom-hook-full-kit" color="#234ba0">Complete digital kit on Cults3D</link>  |  <link href="https://cults3d.com/en/3d-model/home/o25-mm-adhesive-tile-cutting-template-hole-saw-guide-for-hidden-push-to-open-h" color="#234ba0">Free cutting template</link>',styles['HookText']),Paragraph('<link href="https://syntheos.site/checklist/" color="#234ba0">syntheos.site/checklist/</link>',styles['HookSmall']),Spacer(1,10),Paragraph('Planning aid only. Use the creator\'s documentation for the actual model and installation. Product details above come from the listing and have not been independently tested. No verified load rating is provided here.',styles['HookSmall'])]
doc=SimpleDocTemplate(str(root/'public/downloads/Hidden_Tile_Hook_Checklist.pdf'),pagesize=A4,rightMargin=48,leftMargin=48,topMargin=38,bottomMargin=35,title='Hidden Tile Hook — Free Pre-Build Checklist',author='Hidden Tile Hook')
doc.build(story)
print('Created one-page checklist PDF.')
