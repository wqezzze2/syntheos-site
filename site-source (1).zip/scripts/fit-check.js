(() => {
  const messages = {
    en: {
      hollow: ['This kit is outside the stated wall use.', 'Tile over a hollow wall or board on framing is excluded by the creator. Review the alternatives before choosing a hook.', '/guides/hidden-hook-vs-standard-hook/', 'Compare the alternatives'],
      wall: ['Confirm the wall construction first.', 'The tile finish cannot tell you what is behind it. Establish whether the backing is solid before considering this kit.', '/guides/solid-wall-hidden-hook/', 'Read the wall guide'],
      shallow: ['The stated installation depth is unavailable.', 'The listing calls for roughly 80 mm behind the tile in suitable solid material. Review a different location or fitting.', '/guides/hidden-hook-vs-standard-hook/', 'Compare the alternatives'],
      depth: ['Check the available depth first.', 'Confirm the solid backing and the full assembly dimensions. Check for concealed pipes and wiring before any drilling.', '/checklist/', 'Get the free pre-build checklist'],
      printing: ['Arrange printing before buying the files.', 'This is a digital STL / 3MF kit. A finished hook is not shipped, so allow for a printer or printing service.', '/guides/hidden-towel-hook-stl/', 'See what the digital kit includes'],
      hardware: ['Check the exact long K-Push mechanism.', 'The latch is a separate purchase. Confirm its version and dimensions against the creator’s documentation before ordering.', '/guides/long-k-push-hook-kit/', 'Review the separate hardware'],
      review: ['You are ready to review the full kit.', 'Your answers cover the initial requirements. Compare the exact dimensions, hardware and installation instructions on Cults3D before buying or cutting.', 'https://cults3d.com/en/3d-model/home/under-tile-towel-hook-concealed-k-push-hidden-bathroom-hook-full-kit', 'View the kit and current price']
    },
    de: {
      hollow: ['Dieser Wandaufbau ist nicht vorgesehen.', 'Fliesen auf Hohlwänden oder Platten auf Unterkonstruktion sind laut Ersteller ausgeschlossen. Prüfen Sie die Alternativen.', '/de/guides/hidden-hook-vs-standard-hook/', 'Alternativen vergleichen'],
      wall: ['Zuerst den Wandaufbau bestätigen.', 'Die Fliesenoberfläche zeigt nicht, was dahinter liegt. Prüfen Sie, ob der Untergrund massiv ist.', '/de/guides/solid-wall-hidden-hook/', 'Den Wandratgeber lesen'],
      shallow: ['Die angegebene Einbautiefe ist nicht verfügbar.', 'Die Beschreibung nennt etwa 80 mm hinter der Fliese in geeignetem massivem Material. Prüfen Sie einen anderen Ort oder Haken.', '/de/guides/hidden-hook-vs-standard-hook/', 'Alternativen vergleichen'],
      depth: ['Zuerst die verfügbare Tiefe prüfen.', 'Prüfen Sie den massiven Untergrund und die vollständigen Einbaumaße. Vor dem Bohren verdeckte Leitungen und Rohre prüfen.', '/de/guides/solid-wall-hidden-hook/', 'Platz und Untergrund prüfen'],
      printing: ['Den 3D-Druck vor dem Kauf organisieren.', 'Das Angebot ist ein digitales STL-/3MF-Set. Sie benötigen einen eigenen Drucker oder einen Druckservice.', '/de/guides/hidden-towel-hook-stl/', 'Den Umfang des digitalen Sets ansehen'],
      hardware: ['Den genauen langen K-Push prüfen.', 'Die Mechanik wird separat gekauft. Vergleichen Sie Version und Maße mit der Dokumentation des Erstellers.', '/de/guides/long-k-push-hook-kit/', 'Separate Mechanik prüfen'],
      review: ['Sie können nun das vollständige Set prüfen.', 'Ihre Antworten decken die ersten Voraussetzungen ab. Vergleichen Sie vor dem Kauf und Einbau die genauen Maße, die Mechanik und die Anleitung auf Cults3D.', 'https://cults3d.com/en/3d-model/home/under-tile-towel-hook-concealed-k-push-hidden-bathroom-hook-full-kit', 'Set und aktuellen Preis ansehen']
    }
  };
  document.querySelectorAll('[data-fit-check]').forEach(form => {
    const result = form.querySelector('[data-fit-result]');
    const update = () => {
      const {wall, depth, printing, hardware} = form.elements;
      if (![wall, depth, printing, hardware].every(field => field.value)) return;
      const state = wall.value === 'hollow' ? 'hollow' : wall.value !== 'solid' ? 'wall' : depth.value === 'no' ? 'shallow' : depth.value !== 'yes' ? 'depth' : printing.value !== 'yes' ? 'printing' : hardware.value !== 'yes' ? 'hardware' : 'review';
      const [title, text, href, label] = (messages[form.dataset.lang] || messages.en)[state];
      result.querySelector('[data-fit-title]').textContent = title;
      result.querySelector('[data-fit-text]').textContent = text;
      const link = result.querySelector('[data-fit-link]');
      link.href = href;
      link.textContent = label;
      if (state === 'review') link.dataset.event = 'buy_click';
      else delete link.dataset.event;
      result.dataset.state = state;
      result.hidden = false;
    };
    form.addEventListener('submit', event => { event.preventDefault(); update(); });
    form.addEventListener('change', () => { if (!result.hidden) { result.hidden = true; update(); } });
    form.hidden = false;
  });
})();
