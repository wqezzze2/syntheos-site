import {BUY} from '@/lib/product';

export default function FitCheck({lang='en'}:{lang?:'en'|'de'}){
  const de=lang==='de';
  const fields=de?[
    ['wall','1. Was befindet sich hinter der Fliese?',[['','Bitte auswählen'],['solid','Bestätigte massive Wand'],['hollow','Hohlwand / Platten auf Unterkonstruktion'],['unknown','Noch nicht bekannt']]],
    ['depth','2. Sind etwa 80 mm Tiefe verfügbar?',[['','Bitte auswählen'],['yes','Geprüft: ausreichend Tiefe im massiven Untergrund'],['no','Nein'],['unknown','Noch nicht geprüft']]],
    ['printing','3. Haben Sie Zugang zu 3D-Druck?',[['','Bitte auswählen'],['yes','Eigener Drucker oder Druckservice'],['no','Noch nicht']]],
    ['hardware','4. Ist die separate Mechanik eingeplant?',[['','Bitte auswählen'],['yes','Passender langer K-Push ist eingeplant'],['unknown','Ich muss die Mechanik noch prüfen']]]
  ]:[
    ['wall','1. What is behind your tile?',[['','Choose an answer'],['solid','Confirmed solid wall'],['hollow','Hollow wall / board over framing'],['unknown','I do not know yet']]],
    ['depth','2. Is about 80 mm of depth available?',[['','Choose an answer'],['yes','Checked: enough depth in the solid backing'],['no','No'],['unknown','Not checked yet']]],
    ['printing','3. Can you access 3D printing?',[['','Choose an answer'],['yes','My printer or a printing service'],['no','Not yet']]],
    ['hardware','4. Have you allowed for the separate latch?',[['','Choose an answer'],['yes','A matching long K-Push is in the plan'],['unknown','I need to check the mechanism']]]
  ];
  return <form className="fit-check card" data-fit-check="" data-lang={lang} hidden>
    <h3>{de?'Was ist Ihr nächster Schritt?':'What is your next step?'}</h3>
    <p>{de?'Vier kurze Fragen, bevor Sie die Dateien auswählen.':'Four quick questions before choosing the files.'}</p>
    <div className="fit-fields">{fields.map(([name,title,options])=><label key={name as string} htmlFor={'fit-'+name}><span>{title as string}</span><select id={'fit-'+name} name={name as string} required>{(options as string[][]).map(([value,label])=><option key={value} value={value}>{label}</option>)}</select></label>)}</div>
    <button type="submit" className="button">{de?'Nächsten Schritt anzeigen':'Show my next step'}</button>
    <div className="fit-result" data-fit-result="" role="status" aria-live="polite" hidden><h4 data-fit-title=""></h4><p data-fit-text=""></p><a className="text-link" data-fit-link="" href={BUY}></a></div>
    <p className="fine">{de?'Eine Orientierung anhand der Modellbeschreibung. Die vollständige Dokumentation und die Prüfung Ihrer Wand bleiben erforderlich.':'An initial check based on the model listing. Review the full documentation and your actual wall before installation.'}</p>
  </form>;
}
