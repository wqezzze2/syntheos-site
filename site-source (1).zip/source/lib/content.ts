import data from './guides.json';import queue from './pins.json';export const guides=data;export const pins=queue;
