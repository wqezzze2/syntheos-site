export const ORIGIN='https://syntheos.site';
export const BUY='https://cults3d.com/en/3d-model/home/under-tile-towel-hook-concealed-k-push-hidden-bathroom-hook-full-kit';
export const FREE='https://cults3d.com/en/3d-model/home/o25-mm-adhesive-tile-cutting-template-hole-saw-guide-for-hidden-push-to-open-h';
