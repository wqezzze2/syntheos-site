# Hidden Tile Hook on syntheos.site

Source for the Hidden Tile Hook site on `syntheos.site`. The original Syntheos preview is preserved under `legacy/` and in Git history.

## Build

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm run build
```

The generator renders the existing TSX content to plain HTML using React server rendering. It does not deploy a Next.js or Worker server. Output: `_site/` with 16 English/German pages, a one-page downloadable checklist, 24 campaign images, canonical/hreflang metadata, sitemap, robots, favicon, domain CNAME and dated RSS.

## Publication

In Settings → Pages choose GitHub Actions. The workflow builds and deploys `_site/` on pushes to `main`, manual dispatch and Mondays/Wednesdays/Fridays at 08:15 UTC (13:15 Tyumen). Scheduled workflow execution can be delayed by GitHub; the first live RSS ingestion must be checked.

The existing root `CNAME` is `syntheos.site`; verify current Pages settings and DNS before changing anything. DNS was not changed during preparation. Deployment and HTTPS must be confirmed from the real Actions run and public domain before calling the migration complete.

## Pinterest

Account: Samdarom / monerhonda. Secure browser sign-in succeeded on 2026-10-06. The original Sites domain has been claimed successfully. Direct media upload was denied by the browser permission prompt; no Pin was published and RSS auto-publication was not enabled. Do not route around that denial; wait for explicit renewed authorization to upload/publish.

After this domain is live, claim `syntheos.site` with the existing public domain verification tag, connect `https://syntheos.site/feed.xml` to the appropriate public board and verify the first actual Pin. Preserve GUIDs and item dates. Feed entries appear according to their `publishAt` dates at build time. Do not claim traffic, unique visitors or purchases without the corresponding real data.

## Aggregate counts

Static pages send four anonymous aggregate event types to the existing Sites endpoint: `https://hidden-tile-hook.lkje24321.chatgpt.site/api/event`. No cookies or credentials are sent. The backend allows only its own origin and `https://syntheos.site`, with no credentialed CORS. Its cloud DB and weekly content automation remain separate from GitHub Pages. Raw counts are not unique visitors or paid purchases. Cross-domain counting needs a live browser check after deployment; local contract checks alone do not confirm production delivery.

## Content and assets

Editable page sources are in `source/app/`; English/German guides and queue are in `source/lib/`. Images and checklist are in `public/`. The hero is explicitly a concept illustration, not a photograph or load test. The real kit and free template remain on Cults3D.

The checked-in PDF already points to syntheos.site. To regenerate it, use `python scripts/create-checklist.py` with ReportLab installed; CI does not require Python or regenerate the unchanged PDF.

## Preserved previous preview

Original corporate files are available under `legacy/`. They are not included in the hook sitemap and robots excludes that directory from crawling. The existing content is preserved for recovery, not represented as verified corporate claims about the hook project.
